export const users = [
  {
    id: 1,
    username: "janph",
    // password: myPassword (12 rounds)
    passwordHash: "$2b$10$ualYGy1KEbtl1SgIZGwqPecPmWHB6QkJvgFUrJEi9luISGD5Vxgui"
  },
  { id: 2, username: "alice", passwordHash: "$2b$10$AtptVnSsQLpbbxTPX6LweRdiT/ThCLDRLho3LyyYMHzkoRgF6mD6" }
];
